import React, { useEffect, useState } from 'react'
import { useAuth } from './context/authContext'
import axios from 'axios';

const Home = () => {
  const [auth] =  useAuth();
  console.log(auth?.user?.username)
  const[data, setData] = useState([]);
  const disEmp = async () =>{
    try{
    const res = await axios.get(`http://localhost:8000/emp-list/${auth?.user?.username}`)
    console.log(res.data.data);
    setData(res.data.data)
    }catch(e){
      console.log(e)
    }
  }
useEffect(() => {
  disEmp();   
}, [auth]);

  return (
    <div>
      <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-800">Welcome, {auth?.user?.username}!</h1>

      <div className="overflow-x-auto mt-6">
        <table className="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
          <thead className="bg-gray-800 text-white">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold">Employee Name</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Score</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Created At</th>
            </tr>
          </thead>
          <tbody>
            {data.length > 0 ? (
              data.map((emp, index) => (
                <tr key={index} className="border-b hover:bg-gray-100">
                  <td className="px-6 py-4">{emp.emp_name}</td>
                  <td className="px-6 py-4">{emp.score}</td>
                  <td className="px-6 py-4">{new Date(emp.created_at).toLocaleString()}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="3" className="px-6 py-4 text-center text-gray-500">No employees found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>  
    </div>
  )
}

export default Home
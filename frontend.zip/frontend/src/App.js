 
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
function App() {
  return (
   <BrowserRouter>
     <Routes>
       <Route element={<Home/>} index />
       <Route element={<Login/>} path='/admin-login' />
     </Routes>
   </BrowserRouter>
  );
}

export default App;

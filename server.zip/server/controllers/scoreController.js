
import connect from '../connection/db.js'
export const sparta_add_employee = async (req, res) => {
  try {
    const {user_id, user_name, emp_name, score, } = req.body;

    const [insertResult] = await connect.execute(
      "INSERT INTO score_data (user_id, user_name, emp_name, score, created_at) VALUES (?, ?, ?, ?, NOW());",
      [user_id, user_name, emp_name, score]
    );

    res.status(200).send({
      success: true,
      message: "Employee added successfully",
      data: insertResult
    });
   
  }catch (error) {
    res.status(500).send({ success: false, message: "Error adding user" });
  }
};

export const update_score = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { score } = req.body;

    const query = "UPDATE score_data SET score = ? WHERE id = ?";
    const values = [score, id];

    connect.execute(query, values, (error, result) => {
      if (error) {
        return res.status(500).send({
          success: false,
          message: "Error updating score",
        });
      }
      res.status(200).send({
        success: true,
        message: "Score updated successfully",
      });
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Error updating score",
    });
  }
};


export const delete_employee = async (req, res) => {
  try {
    const id = Number(req.params.id);

    const query = "DELETE FROM score_data WHERE id = ?";
    const values = [id];

    connect.execute(query, values, (error, result) => {
      if (error) {
        return res.status(500).send({
          success: false,
          message: "Error deleting employee",
        });
      }
      res.status(200).send({
        success: true,
        message: "Successfully deleted. Redirect to the same page.",
      });
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Error deleting employee",
    });
  }
};

export const displayEmp = async (req, res) => {
  try {
    const { username } = req.params;
   

    if (!username) {
      return res.status(400).json({
        success: false,
        message: "User ID is required",
      });
    }

    // Execute query correctly
    const result = await connect.execute(
      "SELECT * FROM score_data WHERE user_name = ? ORDER BY created_at DESC;",
      [username]
    );

 

    // `result` is an array where the first element contains rows
    const [rows] = result;

    if (!rows || rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No score data found for this user",
      });
    }

    res.status(200).json({
      success: true,
      message: "Score data retrieved successfully",
      data: rows,
    });

  } catch (error) {
    console.error("Database Error:", error);
    res.status(500).json({
      success: false,
      message: "Error retrieving score data",
      error: error.message,
    });
  }
};

 


 

 

